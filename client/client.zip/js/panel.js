/**
 * Atomizer-Software-UI
 * @license Copyright (C) 2012, Atomizer Software
 * http://atomizersoft.net
 *
 * @author Atomizer Software
 */

/**
 *
 * @param id
 * @constructor
 * @namespace
 */
var Panel = function (id) {
    this.id = id;
    this.isOpen = false;
    this.isDisabled = false;
    this.vertPos = null;
    this.horiPos = null;

};
